Face Recognition Models
=======================

This package contains only the models used by `face_recognition <https://github.com/ageitgey/face_recognition>`__.

See  `face_recognition <https://github.com/ageitgey/face_recognition>`__ for more information.

These models were created by `Davis King <https://github.com/davisking/dlib-models>`__ and are licensed in the public domain
or under CC0 1.0 Universal. See LICENSE.
